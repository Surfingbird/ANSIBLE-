#!/bin/perl

use warnings;
use strict;

open(my $fh, '<', '/var/named/chroot/etc/named.conf') or die "can not open named.conf for reeding!";

my @array = <$fh>;
$array[12] =~ s/127\.0\.0\.1\;/any\;/;
$array[13] =~ s/\:\:1\;/none\;/;
$array[18] =~ s/localhost\;/127\.0\.0\.1\; 192\.168\.142\.0\/24\;/;
$array[31] = "\t".'allow-recursion { 127.0.0.1; 192.168.142.0/24; };'."\n"."\t".'forwarders { 8.8.8.8; };'."\n"."\t".'version «DNS Server»;'."\n";

close $fh;

open(my $fh2, '>', '/var/named/chroot/etc/named.conf') or die "can not open named.conf for writing";

print $fh2  @array;


